#ifndef __AST_PARCOURS__
#define __AST_PARCOURS__

#include "type_ast.h"


void afficherA(Ast expr) ;
// affiche l'arbre abstrait de l'expression arithmetique expr


#endif

